const coopManager = {
  unlockedCoops: new Set(),

  initializeCoopStates() {
    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      const coopKey = `${animalType}Coop`;
      // Only initialize if the coop state doesn't exist
      if (!gameState[coopKey]) {
        gameState[coopKey] = {
          owned: false,
          level: 1,
          baseTime: config.baseTime,
          timer: config.baseTime,
          stored: 0,
          eggsMerged: 0, // Track total eggs merged for this coop's type
        };
      }
    }
  },

  generateBuyAnimalButtons() {
    console.log("generateBuyAnimalButtons called");
    console.log(`gameState.eggButtonClicked: ${gameState.eggButtonClicked}`);

    let html = "";

    for (const [animalType, config] of Object.entries(
      GAME_CONFIG.purchaseConfig
    )) {
      const animalConfig = GAME_CONFIG.animalTypes[animalType];
      const imageSrc = GAME_CONFIG.animalImages[animalType];
      const costText = config.cost === 0 ? "Free" : `${config.cost}`;
      const hiddenClass = config.unlocked ? "" : "hidden";

      // Add initial animation class only for the free egg if it hasn't been clicked
      let animationClass = "";
      if (
        animalType === "Egg" &&
        config.cost === 0 &&
        !gameState.eggButtonClicked
      ) {
        console.log("Adding egg-button-pulse class to Egg button");
        animationClass = "egg-button-pulse";
      } else if (animalType === "Egg") {
        console.log(
          `Not adding animation to Egg button - cost: ${config.cost}, clicked: ${gameState.eggButtonClicked}`
        );
      }

      html += `
        <button id="buy${animalType}" class="egg-buy-button enhanced-button buy-button w-full px-4 py-3 rounded-xl shadow-lg font-bold text-white ${hiddenClass} ${animationClass}">
            <span>${animalConfig.name} (${costText})</span> <img src="${imageSrc}" alt="${animalType}" class="inline-animal-icon" />
        </button>
      `;
    }

    return html;
  },

  generateCoopHTML() {
    let html = "";

    // Add empty state message that will be shown/hidden as needed
    html += `
    `;

    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      const animalName =
        animalType.charAt(0).toUpperCase() + animalType.slice(1);
      const producedType = config.producesType;
      const producedImage = GAME_CONFIG.animalImages[producedType];
      const producedConfig = GAME_CONFIG.animalTypes[producedType];
      const coopState = gameState[`${animalType}Coop`] || {
        level: 1,
        stored: 0,
        owned: false,
        eggsMerged: 0,
      };

      // FIX: Determine visibility classes based on actual ownership state
      const unpurchasedClass = coopState.owned ? "hidden" : "";
      const purchasedClass = coopState.owned ? "" : "hidden";

      // Calculate current production time and next level requirement
      const currentTime = this.calculateCoopProductionTime(
        animalType,
        coopState.level
      );
      const nextLevelRequirement = this.getCoopNextLevelRequirement(
        coopState.level
      );

      // Start hidden - will be shown when unlocked
      html += `
        <div id="${animalType}Coop" class="compact-coop hidden">
          <div class="coop-header">
            <div class="flex justify-between items-center">
              <h3 class="coop-title">${animalName} Coop</h3>
              <span class="text-xs text-gray-600">Lv.${coopState.level}</span>
            </div>
          </div>
          
          <div class="text-center">
            <button id="place${producedType}" class="coop-egg-button hidden" style="background: none; border: none; cursor: pointer; padding: 0;">
              <img src="${producedImage}" alt="${producedType}" style="width: 60px; height: 60px; object-fit: contain; margin: 0 auto; border-radius: 8px; transition: transform 0.2s ease;" />
            </button>
          </div>
          
          <div id="${animalType}CoopUnpurchased" class="coop-unpurchased ${unpurchasedClass}">
            <button id="buy${animalName}Coop" class="enhanced-button buy-button coop-buy-btn">
              <i class="fas fa-home mr-1"></i>(${config.buyCost})
            </button>
          </div>

          <div id="${animalType}CoopPurchased" class="coop-purchased ${purchasedClass}">
            <div class="coop-stats">
              <div class="space-y-1 text-xs">
                <div class="flex justify-between">
                  <span>Interval:</span>
                  <span id="${animalType}CoopTimer" class="font-mono">${currentTime.toFixed(
        1
      )}s</span>
                </div>
                <div id="${animalType}CoopProgress" class="text-gray-500">${
        coopState.eggsMerged
      }/${nextLevelRequirement} ${producedConfig.name}s merged</div>
              </div>
              
              
              <div id="${animalType}CoopLevelContainer" class="">
                <div class="coop-progress-bar h-1">
                  <div id="${animalType}CoopLevelBar" class="coop-progress-fill" style="width: 0%"></div>
                </div>
              </div>
              

              <div class="coop-next-level">
              
                            <div class="coop-progress-container">
                <div class="coop-progress-label">Next ${
                  producedConfig.name
                }</div>
                <div class="coop-progress-bar">
                  <div id="${animalType}CoopProductionProgress" class="coop-progress-fill" style="width: 0%"></div>
                </div>
              </div>
              
                <div class="coop-stored-display">
                  <span id="${animalType}CoopStored">Stored: ${
        coopState.stored
      }</span>
                </div>
              </div>




            </div>
          </div>
        </div>
      `;
    }

    return html;
  },

  updatePanelVisibility() {
    // Always call to update visibility based on created animals
    this.updateCoopVisibility();
    this.updateEmptyMessageVisibility();
  },

  initializeFarmBuildingEventListeners() {
    console.log("initializeFarmBuildingEventListeners called");

    for (const [animalType, config] of Object.entries(
      GAME_CONFIG.purchaseConfig
    )) {
      const buyButton = document.getElementById(`buy${animalType}`);
      console.log(
        `Setting up event listener for ${animalType} button:`,
        buyButton
      );

      if (buyButton) {
        // Add hover sound for buttons
        // buyButton.addEventListener("mouseenter", () => {
        //   audioManager.playSound("button-hover");
        // });

        if (config.cost === 0) {
          console.log(`${animalType} is free - adding placeAnimal listener`);
          buyButton.addEventListener("click", () => {
            console.log(`Free ${animalType} button clicked`);

            // Play button click sound
            audioManager.playSound("button-click");

            // Handle egg button clicked state for free eggs
            if (animalType === "Egg" && !gameState.eggButtonClicked) {
              console.log("Setting eggButtonClicked to true for free egg");
              gameState.eggButtonClicked = true;
              eventManager.stopInitialEggButtonAnimation();
              this.updateBuyAnimalButtons();
            }

            placeAnimal(animalType);
          });
        } else {
          console.log(
            `${animalType} costs ${config.cost} - adding buyAnimal listener`
          );
          buyButton.addEventListener("click", () => {
            console.log(`Paid ${animalType} button clicked`);

            // Play button click sound
            audioManager.playSound("button-click");

            buyAnimal(animalType, config.cost);
          });
        }
      }
    }

    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      const animalName =
        animalType.charAt(0).toUpperCase() + animalType.slice(1);
      const producedType = config.producesType;

      const buyButton = document.getElementById(`buy${animalName}Coop`);
      if (buyButton) {
        // Add hover sound for coop buy buttons
        buyButton.addEventListener("mouseenter", () => {
          audioManager.playSound("button-hover");
        });

        buyButton.addEventListener("click", () => {
          audioManager.playSound("button-click");
          this.buyCoop(animalType);
        });
      }

      const placeButton = document.getElementById(`place${producedType}`);
      if (placeButton) {
        // Add hover sound for place buttons
        // placeButton.addEventListener("mouseenter", () => {
        //   audioManager.playSound("button-hover");
        // });

        placeButton.addEventListener("click", () => {
          audioManager.playSound("button-click");
          this.placeStoredAnimal(animalType, producedType);
        });
      }

      const infoButton = document.getElementById(`coopInfo${animalType}`);
      if (infoButton) {
        infoButton.addEventListener("click", (e) => {
          e.stopPropagation();
          audioManager.playSound("button-click");
          this.toggleCoopTooltip(animalType);
        });
      }
    }
  },

  updateBuyAnimalButtons() {
    console.log("updateBuyAnimalButtons called");
    console.log(`gameState.eggButtonClicked: ${gameState.eggButtonClicked}`);

    for (const [animalType, config] of Object.entries(
      GAME_CONFIG.purchaseConfig
    )) {
      const button = document.getElementById(`buy${animalType}`);
      console.log(`Checking button for ${animalType}:`, button);

      if (button) {
        if (config.unlocked) {
          button.classList.remove("hidden");
        } else {
          button.classList.add("hidden");
        }

        // Remove egg button pulse animation if egg was clicked
        if (animalType === "Egg" && gameState.eggButtonClicked) {
          console.log(
            "Removing egg-button-pulse class from Egg button in updateBuyAnimalButtons"
          );
          console.log("Classes before removal:", button.className);
          button.classList.remove("egg-button-pulse");
          console.log("Classes after removal:", button.className);
        }
      }
    }
  },

  buyCoop(animalType) {
    const config = GAME_CONFIG.coopConfig[animalType];
    const cost = config.buyCost;
    const animalName = animalType.charAt(0).toUpperCase() + animalType.slice(1);
    const producedType = config.producesType;

    if (gameState.money >= cost) {
      gameState.money -= cost;
      gameState[`${animalType}Coop`].owned = true;

      // Play coop bought sound
      audioManager.playSound("coop-bought");

      const unpurchasedElement = document.getElementById(
        `${animalType}CoopUnpurchased`
      );
      const purchasedElement = document.getElementById(
        `${animalType}CoopPurchased`
      );

      if (unpurchasedElement) {
        unpurchasedElement.classList.add("hidden");
      }

      if (purchasedElement) {
        purchasedElement.classList.remove("hidden");
      }

      // Unlock the corresponding egg for purchase
      if (GAME_CONFIG.purchaseConfig[producedType]) {
        GAME_CONFIG.purchaseConfig[producedType].unlocked = true;
        this.updateBuyAnimalButtons();
      }

      updateMoney();
      this.updateEmptyMessageVisibility();
      eventManager.showAchievement(`🏡 ${animalName} Coop Purchased!`);
      updateStatus(`Bought ${animalType} coop 🏡`);
      saveManager.saveOnAction(); // Save after buying coop

      // Check achievements after buying coop
      achievementManager.checkAchievements();

      // Update background music in case this unlocks new music
      audioManager.updateBackgroundMusic();
    } else {
      // Play invalid action sound for insufficient funds
      audioManager.playSound("invalid-action");
      updateStatus(`Not enough money for ${animalType} coop! 😕`);
      document.body.classList.add("screen-shake");
      setTimeout(() => document.body.classList.remove("screen-shake"), 500);
    }
  },

  toggleCoopTooltip(animalType) {
    const existingTooltip = document.getElementById("coopTooltip");
    if (existingTooltip) {
      this.hideCoopTooltip();
    } else {
      this.showCoopTooltip(animalType);
    }
  },

  showCoopTooltip(animalType) {
    const coop = gameState[`${animalType}Coop`];
    const config = GAME_CONFIG.coopConfig[animalType];
    const animalName = animalType.charAt(0).toUpperCase() + animalType.slice(1);
    const producedType = config.producesType;
    const producedConfig = GAME_CONFIG.animalTypes[producedType];
    const infoButton = document.getElementById(`coopInfo${animalType}`);

    if (!coop.owned || !infoButton) return;

    this.hideCoopTooltip();

    const tooltip = document.createElement("div");
    tooltip.id = "coopTooltip";
    tooltip.className = "coop-tooltip-fixed";

    // FIX: Calculate current production time based on level
    const currentTime = this.calculateCoopProductionTime(
      animalType,
      coop.level
    );

    tooltip.innerHTML = `
      <div class="tooltip-header">
        <strong>${animalName} Coop (Level ${coop.level})</strong>
      </div>
      <div class="tooltip-content">
        <div class="tooltip-row">Produces: ${producedConfig.name}</div>
        <div class="tooltip-row">Generation time: ${currentTime.toFixed(
          1
        )}s</div>
        <div class="tooltip-row">Stored: ${coop.stored}</div>
        <div class="tooltip-row">Speed bonus: ${(
          (1 - Math.pow(0.9, coop.level - 1)) *
          100
        ).toFixed(0)}%</div>
      </div>
    `;

    document.body.appendChild(tooltip);

    const buttonRect = infoButton.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();

    let left = buttonRect.left - tooltipRect.width - 10;
    let top = buttonRect.top + (buttonRect.height - tooltipRect.height) / 2;

    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    if (left < 10) {
      left = buttonRect.right + 10;
    } else if (left + tooltipRect.width > viewportWidth - 10) {
      left = viewportWidth - tooltipRect.width - 10;
    }

    if (top < 10) {
      top = 10;
    } else if (top + tooltipRect.height > viewportHeight - 10) {
      top = viewportHeight - tooltipRect.height - 10;
    }

    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${top}px`;

    setTimeout(() => {
      const clickOutsideHandler = (e) => {
        if (!tooltip.contains(e.target) && e.target !== infoButton) {
          this.hideCoopTooltip();
          document.removeEventListener("click", clickOutsideHandler);
        }
      };
      document.addEventListener("click", clickOutsideHandler);
    }, 100);
  },

  hideCoopTooltip() {
    const tooltip = document.getElementById("coopTooltip");
    if (tooltip) {
      tooltip.remove();
    }
  },

  placeStoredAnimal(animalType, producedType) {
    const coop = gameState[`${animalType}Coop`];

    if (coop.stored > 0 && placeAnimal(producedType)) {
      coop.stored -= 1;
      document.getElementById(
        `${animalType}CoopStored`
      ).textContent = `Stored: ${coop.stored}`;

      if (coop.stored === 0) {
        document.getElementById(`place${producedType}`).classList.add("hidden");
        document
          .getElementById(`place${producedType}`)
          .classList.remove("pulse");
      }
      this.updatePlaceButtonStates();
      saveManager.saveOnAction(); // Save after placing animal from storage
    } else {
      audioManager.playSound("invalid-action");
      updateStatus("Grid is full! 😕");
    }
  },

  updateCoopVisibility() {
    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      const animalName =
        animalType.charAt(0).toUpperCase() + animalType.slice(1);

      // Check if the actual animal (not egg) has been created to unlock the coop
      if (gameState.createdAnimals.has(animalName)) {
        const coopElement = document.getElementById(`${animalType}Coop`);

        if (coopElement && coopElement.classList.contains("hidden")) {
          coopElement.classList.remove("hidden");
          coopElement.classList.add("bounce-in");

          // Mark this coop as unlocked so we don't animate it again
          this.unlockedCoops.add(animalType);

          console.log(
            `Showing ${animalName} coop because ${animalName} was created`
          );
        }
      }
    }
  },

  updateEmptyMessageVisibility() {
    const emptyMessage = document.getElementById("emptyFarmMessage");
    if (!emptyMessage) return;

    // Check if any coops are visible
    let hasVisibleCoops = false;
    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      const animalName =
        animalType.charAt(0).toUpperCase() + animalType.slice(1);
      if (gameState.createdAnimals.has(animalName)) {
        hasVisibleCoops = true;
        break;
      }
    }

    if (hasVisibleCoops) {
      emptyMessage.classList.add("hidden");
    } else {
      emptyMessage.classList.remove("hidden");
    }
  },

  updatePlaceButtonStates() {
    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      const producedType = config.producesType;
      const placeButton = document.getElementById(`place${producedType}`);
      const coop = gameState[`${animalType}Coop`];

      if (placeButton && coop && coop.owned) {
        placeButton.disabled = isGridFull() || coop.stored === 0;

        if (coop.stored > 0 && !isGridFull()) {
          placeButton.classList.remove("hidden");
          placeButton.classList.add("pulse");

          // Add hover effect to egg image
          const eggImage = placeButton.querySelector("img");
          if (eggImage) {
            eggImage.style.transform = "scale(1.1)";
          }
        } else {
          placeButton.classList.remove("pulse");

          // Reset egg image transform
          const eggImage = placeButton.querySelector("img");
          if (eggImage) {
            eggImage.style.transform = "scale(1)";
          }

          if (coop.stored === 0) {
            placeButton.classList.add("hidden");
          }
        }
      }
    }
  },

  checkForNewUnlocks(newAnimalType) {
    // Check if this animal type corresponds to a coop (Cat, Panda, Vulture unlock coops)
    const lowerAnimalType = newAnimalType.toLowerCase();
    if (GAME_CONFIG.coopConfig[lowerAnimalType]) {
      if (!this.unlockedCoops.has(lowerAnimalType)) {
        console.log(
          `New unlock detected: ${newAnimalType} -> ${lowerAnimalType} coop`
        );
        this.updateCoopVisibility();
        const animalConfig = GAME_CONFIG.animalTypes[newAnimalType];
        eventManager.showAchievement(`🏡 ${animalConfig.name} Coop Unlocked!`);
      }
    }
  },

  // FIX: New method to calculate eggs needed for next coop level
  getCoopNextLevelRequirement(currentLevel) {
    // Similar to auto-merge, but for coop leveling: 5, 10, 20, 35, 55, 80, 110, 145, etc.
    // Each level requires 5 more eggs than the previous gap
    let requirement = 5;
    let gap = 5;

    for (let level = 1; level < currentLevel; level++) {
      requirement += gap;
      gap += 5;
    }

    return requirement;
  },

  // FIX: New method to calculate production time based on level
  calculateCoopProductionTime(animalType, level) {
    const config = GAME_CONFIG.coopConfig[animalType];
    // Each level reduces time by 10% multiplicatively (0.9^(level-1))
    return config.baseTime * Math.pow(0.9, level - 1);
  },

  // FIX: New method to handle coop leveling when eggs are merged
  checkCoopLevelUp(eggType) {
    // Find which coop produces this egg type
    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      if (config.producesType === eggType) {
        const coop = gameState[`${animalType}Coop`];
        if (coop && coop.owned) {
          const oldLevel = coop.level;
          coop.eggsMerged += 1; // Increment eggs merged counter

          const nextLevelRequirement = this.getCoopNextLevelRequirement(
            coop.level
          );

          // Update progress display
          const progressElement = document.getElementById(
            `${animalType}CoopProgress`
          );
          const levelBarElement = document.getElementById(
            `${animalType}CoopLevelBar`
          );
          const producedConfig = GAME_CONFIG.animalTypes[config.producesType];

          if (progressElement) {
            progressElement.textContent = `${coop.eggsMerged}/${nextLevelRequirement} ${producedConfig.name}s merged`;
          }

          if (levelBarElement) {
            const progress = (coop.eggsMerged / nextLevelRequirement) * 100;
            levelBarElement.style.width = `${Math.min(progress, 100)}%`;

            if (progress >= 90) {
              levelBarElement.classList.add("urgent");
            } else {
              levelBarElement.classList.remove("urgent");
            }
          }

          // Check if coop should level up
          if (coop.eggsMerged >= nextLevelRequirement) {
            coop.level += 1;
            coop.eggsMerged = 0; // Reset counter for next level

            // Update the timer with new production time
            const newTime = this.calculateCoopProductionTime(
              animalType,
              coop.level
            );
            coop.timer = Math.min(coop.timer, newTime); // Don't extend current timer

            // Update UI elements
            const levelDisplay = document.querySelector(
              `#${animalType}Coop .text-xs.text-gray-600`
            );
            const timerDisplay = document.getElementById(
              `${animalType}CoopTimer`
            );

            if (levelDisplay) {
              levelDisplay.textContent = `Lv.${coop.level}`;
            }

            if (timerDisplay) {
              timerDisplay.textContent = `${newTime.toFixed(1)}s`;
            }

            // Reset progress displays for next level
            const newNextRequirement = this.getCoopNextLevelRequirement(
              coop.level
            );
            if (progressElement) {
              progressElement.textContent = `${coop.eggsMerged}/${newNextRequirement} ${producedConfig.name}s merged`;
            }

            if (levelBarElement) {
              levelBarElement.style.width = "0%";
              levelBarElement.classList.remove("urgent");
            }

            // Show achievement
            eventManager.showAchievement(
              `🆙 ${
                animalType.charAt(0).toUpperCase() + animalType.slice(1)
              } Coop Level ${coop.level}!`
            );

            // Play level up sound
            audioManager.playSound("achievement-awarded");

            updateStatus(
              `${
                animalType.charAt(0).toUpperCase() + animalType.slice(1)
              } coop leveled up! Production 10% faster! 🆙`
            );

            console.log(
              `${animalType} coop leveled up from ${oldLevel} to ${coop.level} due to ${eggType} merge`
            );
          }

          saveManager.saveOnAction(); // Save after coop progress update
          break;
        }
      }
    }
  },

  updateCoopTimers() {
    for (const [animalType, config] of Object.entries(GAME_CONFIG.coopConfig)) {
      const coop = gameState[`${animalType}Coop`];
      const producedType = config.producesType;
      const producedConfig = GAME_CONFIG.animalTypes[producedType];

      if (coop.owned) {
        coop.timer -= 1;

        const progressElement = document.getElementById(
          `${animalType}CoopProductionProgress`
        );
        if (progressElement) {
          // FIX: Use the new calculation method for max time
          const maxTime = this.calculateCoopProductionTime(
            animalType,
            coop.level
          );
          const progress = ((maxTime - coop.timer) / maxTime) * 100;
          progressElement.style.width = `${Math.max(0, progress)}%`;

          if (coop.timer <= 3) {
            progressElement.classList.add("urgent");
          } else {
            progressElement.classList.remove("urgent");
          }
        }

        if (coop.timer <= 0) {
          coop.stored += 1;

          // Play specific egg timer sound based on coop type
          // if (animalType === "cat") {
          //   audioManager.playSound("egg-timer-cat");
          // } else if (animalType === "panda") {
          //   audioManager.playSound("egg-timer-panda");
          // } else if (animalType === "vulture") {
          //   audioManager.playSound("egg-timer-vulture");
          // }

          const storedElement = document.getElementById(
            `${animalType}CoopStored`
          );
          if (storedElement) {
            storedElement.textContent = `Stored: ${coop.stored}`;
          }

          const placeButton = document.getElementById(`place${producedType}`);
          if (placeButton) {
            placeButton.classList.remove("hidden");
            placeButton.classList.add("pulse");
            if (!isGridFull()) {
              placeButton.disabled = false;
            }
          }

          // FIX: Reset timer with new production time based on current level
          coop.timer = this.calculateCoopProductionTime(animalType, coop.level);

          // eventManager.showAchievement(`${producedConfig.name} Ready!`);

          const progressElement = document.getElementById(
            `${animalType}CoopProductionProgress`
          );
          if (progressElement) {
            progressElement.style.width = "0%";
            progressElement.classList.remove("urgent");
          }

          saveManager.saveOnAction(); // Save when coop generates an animal
        }
      }
    }
  },

  buyAutoMerge() {
    if (gameState.money >= GAME_CONFIG.autoMergeConfig.buyCost) {
      gameState.money -= GAME_CONFIG.autoMergeConfig.buyCost;
      gameState.autoMerge.owned = true;
      gameState.autoMerge.timer = gameState.autoMerge.currentInterval;

      // Play coop bought sound for auto-merge purchase
      audioManager.playSound("coop-bought");

      document.getElementById("buyAutoMerge").classList.add("hidden");
      document.getElementById("autoMergeToggle").classList.remove("hidden");
      document
        .getElementById("autoMergeProgressContainer")
        .classList.remove("hidden");

      // Update shuffle button state now that auto-merge is owned
      this.updateShuffleButtonState();

      updateMoney();
      eventManager.showAchievement("⚙️ Auto-Merge Activated!");
      updateStatus("Bought Auto-Merge ⚙️");
      saveManager.saveOnAction(); // Save after buying auto-merge

      // Check achievements after buying auto-merge
      achievementManager.checkAchievements();
    } else {
      // Play invalid action sound for insufficient funds
      audioManager.playSound("invalid-action");
      updateStatus("Not enough money for Auto-Merge! 😕");
      document.body.classList.add("screen-shake");
      setTimeout(() => document.body.classList.remove("screen-shake"), 500);
    }
  },

  updateShuffleButtonState() {
    const shuffleButton = document.getElementById("buyShuffle");
    const shuffleButtonText = document.getElementById("shuffleButtonText");

    if (shuffleButton && shuffleButtonText) {
      if (!gameState.autoMerge.owned) {
        // Lock shuffle until auto-merge is purchased
        shuffleButton.disabled = true;
        shuffleButton.style.opacity = "0.5";
        shuffleButton.style.cursor = "not-allowed";
        shuffleButtonText.textContent = "Requires Auto-Merge";
        shuffleButton.title = "Purchase Auto-Merge first to unlock Shuffle";
      } else {
        // Unlock shuffle
        shuffleButton.disabled = false;
        shuffleButton.style.opacity = "1";
        shuffleButton.style.cursor = "pointer";
        shuffleButtonText.textContent = "Buy ($50)";
        shuffleButton.title = "";
      }
    }
  },

  toggleAutoMerge() {
    gameState.autoMerge.enabled = !gameState.autoMerge.enabled;
    const button = document.getElementById("autoMergeToggle");
    if (gameState.autoMerge.enabled) {
      button.textContent = "🔵 ON";
      button.classList.remove("bg-red-500");
      button.classList.add("bg-green-500");
    } else {
      button.textContent = "🔴 OFF";
      button.classList.remove("bg-green-500");
      button.classList.add("bg-red-500");
    }
    updateStatus(
      `Auto-Merge ${gameState.autoMerge.enabled ? "enabled" : "disabled"}`
    );
    saveManager.saveOnAction(); // Save after toggling auto-merge
  },

  buyShuffle() {
    // Check if auto-merge is owned first
    if (!gameState.autoMerge.owned) {
      audioManager.playSound("invalid-action");
      updateStatus("You need Auto-Merge first! 😕");
      document.body.classList.add("screen-shake");
      setTimeout(() => document.body.classList.remove("screen-shake"), 500);
      return;
    }

    if (gameState.money >= GAME_CONFIG.shuffleConfig.buyCost) {
      gameState.money -= GAME_CONFIG.shuffleConfig.buyCost;
      gameState.shuffle.owned = true;

      // Play coop bought sound for shuffle purchase
      audioManager.playSound("coop-bought");

      document.getElementById("buyShuffle").classList.add("hidden");
      document.getElementById("shuffleToggle").classList.remove("hidden");
      updateMoney();
      eventManager.showAchievement("🔀 Shuffle Activated!");
      updateStatus("Bought Shuffle 🔀");
      saveManager.saveOnAction(); // Save after buying shuffle
    } else {
      // Play invalid action sound for insufficient funds
      audioManager.playSound("invalid-action");
      updateStatus("Not enough money for Shuffle! 😕");
      document.body.classList.add("screen-shake");
      setTimeout(() => document.body.classList.remove("screen-shake"), 500);
    }
  },

  toggleShuffle() {
    gameState.shuffle.enabled = !gameState.shuffle.enabled;
    const button = document.getElementById("shuffleToggle");
    if (gameState.shuffle.enabled) {
      button.textContent = "🔵 ON";
      button.classList.remove("bg-red-500");
      button.classList.add("bg-green-500");
    } else {
      button.textContent = "🔴 OFF";
      button.classList.remove("bg-green-500");
      button.classList.add("bg-red-500");
    }
    updateStatus(
      `Shuffle ${gameState.shuffle.enabled ? "enabled" : "disabled"}`
    );
    saveManager.saveOnAction(); // Save after toggling shuffle
  },

  performShuffle() {
    const animals = [];
    const occupiedCells = [];

    GAME_CONFIG.gridConfig.availableSpots.forEach(({ row: i, col: j }) => {
      if (gameState.purchasedCells.has(`${i}-${j}`)) {
        if (gameState.grid[i][j]) {
          animals.push(gameState.grid[i][j]);
          occupiedCells.push({ i, j });
          gameState.grid[i][j] = null;
        }
      }
    });

    if (animals.length === 0) return;

    // Play shuffle sound
    audioManager.playSound("shuffle");

    GAME_CONFIG.gridConfig.availableSpots.forEach(({ row: i, col: j }) => {
      if (gameState.purchasedCells.has(`${i}-${j}`)) {
        gridManager.updateCell(i, j);
      }
    });

    for (let i = animals.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [animals[i], animals[j]] = [animals[j], animals[i]];
    }

    let animalIndex = 0;
    GAME_CONFIG.gridConfig.availableSpots.forEach(({ row: i, col: j }) => {
      if (
        gameState.purchasedCells.has(`${i}-${j}`) &&
        animalIndex < animals.length
      ) {
        gameState.grid[i][j] = animals[animalIndex];
        gridManager.updateCell(i, j);
        animalIndex++;
      }
    });

    updateMergeablePairs();
    updateStatus("Animals shuffled! 🔀");
  },

  clearAutoMergeHighlight() {
    GAME_CONFIG.gridConfig.availableSpots.forEach(({ row: i, col: j }) => {
      if (gameState.purchasedCells.has(`${i}-${j}`)) {
        const cell = document.getElementById(`cell-${i}-${j}`);
        if (cell) {
          cell.classList.remove(
            "border-purple-500",
            "border-2",
            "border-green-500",
            "new-animal-spawn",
            "auto-merge-glow"
          );
        }
      }
    });
  },

  showAutoMergeGlow() {
    this.clearAutoMergeHighlight();
    this.updateMergeablePairsForAutoMerge();

    const glowCells = new Set();

    gameState.mergeablePairs.forEach(({ source, target }) => {
      glowCells.add(`${source.i}-${source.j}`);
      glowCells.add(`${target.i}-${target.j}`);
    });

    glowCells.forEach((cellKey) => {
      const cell = document.getElementById(`cell-${cellKey}`);
      if (cell) {
        cell.classList.add("auto-merge-glow");
      }
    });
  },

  updateMergeablePairsForAutoMerge() {
    gameState.mergeablePairs = [];

    const neighbors = [
      { di: 0, dj: 1 },
      { di: 1, dj: 0 },
      { di: 0, dj: -1 },
      { di: -1, dj: 0 },
    ];

    GAME_CONFIG.gridConfig.availableSpots.forEach(({ row: i, col: j }) => {
      if (
        gameState.purchasedCells.has(`${i}-${j}`) &&
        gameState.grid[i][j] &&
        GAME_CONFIG.animalTypes[gameState.grid[i][j]].mergeTo
      ) {
        for (const { di, dj } of neighbors) {
          const ni = i + di;
          const nj = j + dj;
          if (
            GAME_CONFIG.gridConfig.availableSpots.some(
              (spot) => spot.row === ni && spot.col === nj
            ) &&
            gameState.purchasedCells.has(`${ni}-${nj}`) &&
            gameState.grid[ni][nj] === gameState.grid[i][j]
          ) {
            const pairExists = gameState.mergeablePairs.some(
              (pair) =>
                (pair.source.i === i &&
                  pair.source.j === j &&
                  pair.target.i === ni &&
                  pair.target.j === nj) ||
                (pair.source.i === ni &&
                  pair.source.j === nj &&
                  pair.target.i === i &&
                  pair.target.j === j)
            );

            if (!pairExists) {
              gameState.mergeablePairs.push({
                source: { i, j },
                target: { i: ni, j: nj },
              });
            }
          }
        }
      }
    });
  },

  autoMergeCheck() {
    if (!gameState.autoMerge.enabled) return;

    this.clearAutoMergeHighlight();

    let mergedTypes = [];
    let mergesMade = false;

    const pairsToProcess = [...gameState.mergeablePairs];

    if (pairsToProcess.length === 0) {
      // Play auto-merge fail sound when no merges available
      audioManager.playSound("auto-merge-fail");
    } else {
      // Play auto-merge win sound when merges happen
      audioManager.playSound("auto-merge-win");
    }

    pairsToProcess.forEach(({ source, target }) => {
      if (
        gameState.grid[source.i][source.j] &&
        gameState.grid[target.i][target.j] &&
        gameState.grid[source.i][source.j] ===
          gameState.grid[target.i][target.j] &&
        GAME_CONFIG.animalTypes[gameState.grid[target.i][target.j]].mergeTo
      ) {
        const sourceType = gameState.grid[source.i][source.j];
        const newType =
          GAME_CONFIG.animalTypes[gameState.grid[target.i][target.j]].mergeTo;

        const sourceCell = document.getElementById(
          `cell-${source.i}-${source.j}`
        );
        const explosion = document.createElement("div");
        explosion.textContent = "⚙️";
        explosion.classList.add("merge-explosion", "absolute", "text-3xl");
        explosion.style.left = "50%";
        explosion.style.top = "50%";
        explosion.style.transform = "translate(-50%, -50%)";
        sourceCell.appendChild(explosion);

        setTimeout(
          () => explosion.remove(),
          GAME_CONFIG.animationConfig.mergeExplosionDuration
        );

        gameState.grid[source.i][source.j] = null;
        gameState.grid[target.i][target.j] = newType;
        gameState.createdAnimals.add(newType);

        // FIX: Check for coop leveling when eggs are merged via auto-merge
        this.checkCoopLevelUp(sourceType);

        document
          .getElementById(`cell-${source.i}-${source.j}`)
          .classList.add("border-green-500", "border-2");
        document
          .getElementById(`cell-${target.i}-${target.j}`)
          .classList.add("border-green-500", "border-2", "new-animal-spawn");

        gridManager.updateCell(source.i, source.j);
        gridManager.updateCell(target.i, target.j);

        eventManager.createParticles(
          document.getElementById(`cell-${target.i}-${target.j}`)
        );

        const newAnimalConfig = GAME_CONFIG.animalTypes[newType];
        if (!mergedTypes.includes(newAnimalConfig.name))
          mergedTypes.push(newAnimalConfig.name);
        mergesMade = true;

        this.checkForNewUnlocks(newType);

        if (newType === "EndDemoAnimal") {
          eventManager.showDemoEndedPopup();
        }
      }
    });

    this.updateMergeablePairsForAutoMerge();

    setTimeout(() => this.clearAutoMergeHighlight(), 1500);
    updateAnimalValues();

    if (mergesMade) {
      const message =
        mergedTypes.length > 0
          ? `Auto-merged into ${mergedTypes.map((t) => t).join(", ")} ⚙️`
          : "Auto-merged animals ⚙️";
      updateStatus(message);

      // Update background music based on new animals created
      audioManager.updateBackgroundMusic();
    }

    // Always trigger shuffle if owned and enabled, regardless of whether merges were made
    if (gameState.shuffle.owned && gameState.shuffle.enabled) {
      setTimeout(() => {
        this.performShuffle();
      }, GAME_CONFIG.shuffleConfig.delayAfterAutoMerge);
    }

    this.updatePlaceButtonStates();
  },

  updateAutoMergeTimer() {
    if (gameState.autoMerge.owned && gameState.autoMerge.enabled) {
      gameState.autoMerge.timer -= 0.1;

      const progressElement = document.getElementById("autoMergeProgressBar");
      if (progressElement) {
        const progress =
          ((gameState.autoMerge.currentInterval - gameState.autoMerge.timer) /
            gameState.autoMerge.currentInterval) *
          100;
        progressElement.style.width = `${Math.max(0, progress)}%`;

        if (gameState.autoMerge.timer <= 3) {
          progressElement.classList.add("urgent");
        } else {
          progressElement.classList.remove("urgent");
        }
      }

      if (Math.abs(gameState.autoMerge.timer - 2) < 0.05) {
        this.showAutoMergeGlow();
      } else if (Math.abs(gameState.autoMerge.timer - 1) < 0.05) {
        this.showAutoMergeGlow();
      } else if (Math.abs(gameState.autoMerge.timer - 0.5) < 0.05) {
        this.showAutoMergeGlow();
      } else if (Math.abs(gameState.autoMerge.timer - 0.25) < 0.05) {
        this.showAutoMergeGlow();
      }

      if (gameState.autoMerge.timer <= 0) {
        this.autoMergeCheck();
        gameState.autoMerge.timer = gameState.autoMerge.currentInterval;

        if (progressElement) {
          progressElement.style.width = "0%";
          progressElement.classList.remove("urgent");
        }
      }
    }
  },
};
